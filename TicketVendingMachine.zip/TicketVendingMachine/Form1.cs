using System.Data;
using System.Data.SqlClient;

namespace TicketVendingMachine
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter adapter;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        void showTicket()
        {
            string s = "select top 1 * from Ticket order by ticketId desc";
            adapter = new SqlDataAdapter(s, con);
            dt = new DataTable();
            adapter.Fill(dt);
            grdTicket.DataSource = dt;
        }

        void showDes()
        {
            string s = "select * from Destination";
            adapter = new SqlDataAdapter(s, con);
            dt = new DataTable();
            adapter.Fill(dt);
            cbDes.DataSource = dt;
            cbDes.DisplayMember = "desname";
            cbDes.ValueMember = "desId";
        }

        void showPay()
        {
            string s = "select * from Payment";
            adapter = new SqlDataAdapter(s, con);
            dt = new DataTable();
            adapter.Fill(dt);
            cbPay.DataSource = dt;
            cbPay.DisplayMember = "paymethod";
            cbPay.ValueMember = "payId";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string sql = "initial catalog = TicketMachine; data source = TUANDACA; integrated security = true";
            con = new SqlConnection(sql);
            con.Open();
            showTicket();
            showDes();
            showPay();
        }

        private void cbDes_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cbPay_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = "insert into Ticket values ('', '', " + cbDes.ValueMember + ", '" + cbPay.ValueMember + "')";
            adapter = new SqlDataAdapter(s, con);
            dt = new DataTable();
            adapter.Fill(dt);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}