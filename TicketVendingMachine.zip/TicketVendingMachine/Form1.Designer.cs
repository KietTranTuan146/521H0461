﻿namespace TicketVendingMachine
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button2 = new Button();
            button1 = new Button();
            grdTicket = new DataGridView();
            cbPay = new ComboBox();
            cbDes = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdTicket).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(grdTicket);
            groupBox1.Controls.Add(cbPay);
            groupBox1.Controls.Add(cbDes);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(7, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(994, 536);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // button2
            // 
            button2.Location = new Point(619, 145);
            button2.Name = "button2";
            button2.Size = new Size(162, 60);
            button2.TabIndex = 6;
            button2.Text = "Cancel";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(285, 145);
            button1.Name = "button1";
            button1.Size = new Size(162, 60);
            button1.TabIndex = 5;
            button1.Text = "Buy Ticket";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // grdTicket
            // 
            grdTicket.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdTicket.Location = new Point(156, 245);
            grdTicket.Name = "grdTicket";
            grdTicket.RowHeadersWidth = 51;
            grdTicket.RowTemplate.Height = 29;
            grdTicket.Size = new Size(716, 285);
            grdTicket.TabIndex = 4;
            // 
            // cbPay
            // 
            cbPay.FormattingEnabled = true;
            cbPay.Location = new Point(354, 81);
            cbPay.Name = "cbPay";
            cbPay.Size = new Size(518, 28);
            cbPay.TabIndex = 3;
            cbPay.SelectedIndexChanged += cbPay_SelectedIndexChanged;
            // 
            // cbDes
            // 
            cbDes.FormattingEnabled = true;
            cbDes.Location = new Point(354, 20);
            cbDes.Name = "cbDes";
            cbDes.Size = new Size(518, 28);
            cbDes.TabIndex = 2;
            cbDes.SelectedIndexChanged += cbDes_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(156, 84);
            label2.Name = "label2";
            label2.Size = new Size(165, 20);
            label2.TabIndex = 1;
            label2.Text = "Chose Payment Method";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(156, 23);
            label1.Name = "label1";
            label1.Size = new Size(129, 20);
            label1.TabIndex = 0;
            label1.Text = "Chose Destination";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1013, 553);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Ticket Vending Machine";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdTicket).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private DataGridView grdTicket;
        private ComboBox cbPay;
        private ComboBox cbDes;
        private Label label2;
        private Label label1;
        private Button button2;
        private Button button1;
    }
}